export const hsaaiBrand = {
  colors: { black: "#050505", charcoal: "#111111", gold: "#C7A833", yellow: "#F0CF3A", white: "#FFFFFF", gray: "#6B7280", softYellow: "#FFF7CC" },
  fonts: { arabic: ["Cairo", "Tajawal"], english: ["Inter", "Aptos"], code: ["Consolas", "JetBrains Mono"] },
  direction: { arabic: "rtl", code: "ltr" }
} as const;
